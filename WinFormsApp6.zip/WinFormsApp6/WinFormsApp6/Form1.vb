﻿Public Class Form1
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            Dim num1 As Double = Double.Parse(txtNum1.Text)
            Dim num2 As Double = Double.Parse(txtNum2.Text)
            Dim result As Double = num1 + num2
            lblResult.Text = "Result: " & result.ToString()
        Catch ex As Exception
            MessageBox.Show("Error: Invalid input!")
        End Try
    End Sub

    Private Sub btnSubtract_Click(sender As Object, e As EventArgs) Handles btnSubtract.Click
        Try
            Dim num1 As Double = Double.Parse(txtNum1.Text)
            Dim num2 As Double = Double.Parse(txtNum2.Text)
            Dim result As Double = num1 - num2
            lblResult.Text = "Result: " & result.ToString()
        Catch ex As Exception
            MessageBox.Show("Error: Invalid input!")
        End Try
    End Sub

    Private Sub btnMultiply_Click(sender As Object, e As EventArgs) Handles btnMultiply.Click
        Try
            Dim num1 As Double = Double.Parse(txtNum1.Text)
            Dim num2 As Double = Double.Parse(txtNum2.Text)
            Dim result As Double = num1 * num2
            lblResult.Text = "Result: " & result.ToString()
        Catch ex As Exception
            MessageBox.Show("Error: Invalid input!")
        End Try

    End Sub

    Private Sub btnDivide_Click(sender As Object, e As EventArgs) Handles btnDivide.Click
        Try
            Dim num1 As Double = Double.Parse(txtNum1.Text)
            Dim num2 As Double = Double.Parse(txtNum2.Text)
            If num2 = 0 Then
                MessageBox.Show("Error: Division by zero!")
            Else
                Dim result As Double = num1 / num2
                lblResult.Text = "Result: " & result.ToString()
            End If
        Catch ex As Exception
            MessageBox.Show("Error: Invalid input!")
        End Try

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
